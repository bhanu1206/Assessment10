import React from "react";
import axios from "axios";

class AxionExample extends React.Component{

    state = {
        elements: []
    }

    componentDidMount()
    {
        axios.get("https://datausa.io/api/data?drilldowns=Nation&measures=Population").then(res =>{
            const elements=res.data;
            console.log(this.state.elements);
            this.setState({elements:elements.data})
        })
    }
    render(){
        return(
            <table border={1}>
                <thead>
                    <tr>
                        <td><b>ID Nation</b></td>
                        <td><b>Population</b></td>
                        <td><b>Year</b></td>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.state.elements.map(element =>
                            <tr key={element['ID Nation']}>
                                <td>{element['ID Nation']}</td>
                                <td>{element.Population}</td>
                                <td>{element.Year}</td>
                            </tr>
                            )
                    }
                </tbody>
            </table>
        )
    }
}
export default AxionExample;