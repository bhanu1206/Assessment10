import React from "react";
import './Pharmavalidation.css';
class Pharmavalidation extends React.Component {
    constructor() {
        super();
        this.state = {
            fields: {},
            errors: {}
        }
        this.handleChange = this.handleChange.bind(this);
        this.formsubmit = this.formsubmit.bind(this);
    }
    handleChange(e) {
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields
        })
    }
    formsubmit(e) {
        e.preventDefault();
        if (this.validate()) {
            alert("Registered Successfully");
        }
    }
    validate() {
        let fields = this.state.fields;
        let errors = {};
        let fvalid = true;
        if (!fields["name"]) {
            fvalid = false;
            errors["name"] ="*Name cannot be empty";
        }
        if (!fields["mobileno"]) {
            fvalid = false;
            errors["mobileno"] = "*Mobile number cannot be empty!";
        }
        if (!fields["Address"]) {
            fvalid = false;
            errors["Address"] = "*Address should not be empty";
        }
        if(!fields["vendorid"]){
            fvalid=false;
            errors["vendorid"] = "*Vendor ID field cannot be empty!."
        }  
        if(!fields["password"]){
            fvalid = false;
            errors["password"] = "*Password cannot be empty!";
        }
        if(!fields["rpassword"]){
            fvalid = false;
            errors["rpassword"] = "*Password cannot be empty!";
        }
        this.setState({
            errors: errors
        });
        return fvalid;
    }
    render() {
        return (
            <div>
                <div id="register">
                    <form method="post" id="register-Form" name="userRegistrationform" onSubmit={this.formsubmit}>
                       <h2>Register New Vendor</h2>
                        <input type="text" placeholder="Enter Name" name="name" value={this.state.fields.name} onChange={this.handleChange}  className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.name}</div>
                     
                        <input type="tel" placeholder="Enter Phone Number" name="mobileno" value={this.state.fields.mobileno} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.mobileno}</div>
                     
                        <input type="text" placeholder="Enter Address" name="Address" value={this.state.fields.Address} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.Address}</div>
 
                        <input type="text" placeholder="Enter Vendor ID" name="vendorid" value={this.state.fields.vendorid} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.vendorid}</div>
 
                        <input type="password" placeholder="Enter Password" name="password" value={this.state.fields.password} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.password}</div>
 
                        <input type="password" placeholder="Retype Password" name="rpassword" value={this.state.fields.rpassword} onChange={this.handleChange} className="bottomcolor"/>
                        <div className="errorvalue">{this.state.errors.rpassword}</div>
                        <input type="submit" value="Submit" className="btn" />
                    </form>
                    <img src="phar.png" alt="image"/>
                </div>
            </div>
        )
    }
}
export default Pharmavalidation;