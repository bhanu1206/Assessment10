import logo from './logo.svg';
import './App.css';
import Pharmavalidation from './Pharmavalidation';
function App() {
  return (
    <Pharmavalidation/>
     
  );
}

export default App;
