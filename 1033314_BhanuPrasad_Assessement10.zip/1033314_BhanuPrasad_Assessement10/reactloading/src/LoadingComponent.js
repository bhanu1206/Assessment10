
import React from "react";
import Spinner from 'react-spinner-material';

class LoadingComponent extends React.Component {
    render() {
    return (
        <div className="loading">
            <h3>loading...</h3>
          <Spinner radius={120} color={"#333"} stroke={2} visible={true} />
        </div>
      );
    }}
export default LoadingComponent;