import React from "react";
import './Loading.css';
class Loading extends React.Component
{
    render()
    {
        return(
            <div className="loading" id="load">
                <h1 className="text">LOADING SCREEN REACTJS</h1>
            </div>
        )
    }
    
}
export default Loading;