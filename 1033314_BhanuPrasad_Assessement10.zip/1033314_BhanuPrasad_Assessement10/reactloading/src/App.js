import logo from './logo.svg';
import './App.css';
import Loading from './Loading';
import LoadingComponent from './LoadingComponent';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" /><p className="Name">React</p>
      </header>
      <div className='space'></div>
      <Loading/>
      <div className='space'></div>
      <LoadingComponent/>
      
    </div>
  );
}

export default App;
